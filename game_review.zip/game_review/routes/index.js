var express = require('express');
var router = express.Router();
var userModel = require('./users')

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('home')
});

router.get("/post", function(req, res, next) {
  res.render('post')
});

router.get('/review', function(req, res, next) {
  userModel.find()
  .then(function(data){
    res.render('read', {data});
  })
});

router.post('/submit', function(req, res, next) {
  userModel.create({
    GameName : req.body.gamename,
    review : req.body.review
})
.then(function(recived){
  res.render('review')
})

});
router.get('/update/:id', function(req, res, next) {
  userModel.findOne({_id: req.params.id})
  .then(function(game){
    res.render('update', {game})
  })

 
  
});

router.post('/update/:id', function(req, res, next) {
  let newData = {
    GameName : req.body.gamename,
    review : req.body.review
  }
  userModel.findOneAndUpdate({_id : req.params.id},
    {"$set": newData},{require:true})
    .then(function (data){
      res.redirect('/review')
    })
  });

router.get('/delete/:id', function(req, res, next) {
   userModel.findOneAndDelete({_id : req.params.id})
       .then(function (data){
      res.redirect('/review')
    })
  });
module.exports = router;
