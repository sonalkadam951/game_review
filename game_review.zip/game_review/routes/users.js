let mongoose = require('mongoose')

mongoose.connect('mongodb://localhost/GamingForum')
.then(function() {
  console.log('database Connected')
})
.catch(function(err){
  console.log(err)
})

let Schema = mongoose.Schema({
  GameName : String,
  review : String
})

module.exports = mongoose.model('user', Schema)